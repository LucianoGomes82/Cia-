const https = require('https');

// Scraping da página de mais vendidos do ML Brasil
// Simula browser real para evitar bloqueio
function fetchML(url) {
  return new Promise((resolve) => {
    const urlObj = new URL(url);
    const req = https.request({
      hostname: urlObj.hostname,
      port: 443,
      path: urlObj.pathname + urlObj.search,
      method: 'GET',
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.9,en;q=0.8',
        'Accept-Encoding': 'identity',
        'Cache-Control': 'no-cache',
        'Referer': 'https://www.mercadolivre.com.br/',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
      }
    }, res => {
      // Segue redirecionamentos
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return fetchML(res.headers.location).then(resolve);
      }
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => resolve({ status: res.statusCode, html: d }));
    });
    req.on('error', e => resolve({ status: 500, html: '', error: e.message }));
    req.setTimeout(10000, () => { req.destroy(); resolve({ status: 408, html: '', error: 'timeout' }); });
    req.end();
  });
}

// Extrai produtos do HTML da página de mais vendidos
function extractProducts(html) {
  const items = [];

  // Padrão 1: polycard (layout atual do ML)
  const polycardRx = /"permalink":"(https:\/\/www\.mercadolivre\.com\.br\/[^"]+)","[^"]*"(?:[^}]*)"title":"([^"]+)"(?:[^}]*)"price":\{"[^"]*":\{"value":(\d+(?:\.\d+)?)/g;
  let m;
  while ((m = polycardRx.exec(html)) !== null && items.length < 30) {
    items.push({ permalink: m[1], title: m[2], price: parseFloat(m[3]) });
  }

  // Padrão 2: JSON de produto no HTML
  if (items.length < 5) {
    const jsonRx = /"id":"(MLB\d+)","title":"([^"]+)","price":(\d+(?:\.\d+)?)(?:[^}]*)"permalink":"([^"]+)"/g;
    while ((m = jsonRx.exec(html)) !== null && items.length < 30) {
      if (!items.find(i => i.id === m[1])) {
        items.push({ id: m[1], title: m[2], price: parseFloat(m[3]), permalink: m[4] });
      }
    }
  }

  // Padrão 3: data-item-id nos elementos HTML
  if (items.length < 5) {
    const itemRx = /data-item-id="(MLB\d+)"[^>]*>.*?<img[^>]*alt="([^"]+)"[^>]*>.*?<span[^>]*>R\$\s*([\d.,]+)/gs;
    while ((m = itemRx.exec(html)) !== null && items.length < 30) {
      const price = parseFloat(m[3].replace('.','').replace(',','.'));
      if (!isNaN(price)) {
        items.push({ id: m[1], title: m[2], price, permalink: `https://www.mercadolivre.com.br/p/${m[1]}` });
      }
    }
  }

  // Extrai sold_quantity se disponível
  const soldRx = /"id":"(MLB\d+)"[^}]*"sold_quantity":(\d+)/g;
  const soldMap = {};
  while ((m = soldRx.exec(html)) !== null) soldMap[m[1]] = parseInt(m[2]);

  return items.map((item, i) => ({
    id:            item.id || `MLB-${i}`,
    title:         item.title.replace(/&amp;/g,'&').replace(/&#39;/g,"'").replace(/&quot;/g,'"').trim(),
    price:         item.price || 0,
    sold_quantity: soldMap[item.id] || null,
    permalink:     item.permalink,
    listing_type_id: 'gold_special',
  })).filter(i => i.title && i.price > 0);
}

// Mapa de URLs de mais vendidos por categoria/marca
const MAIS_VENDIDOS = {
  // Categorias
  'celulares':    'https://www.mercadolivre.com.br/mais-vendidos/MLB1055',
  'celular':      'https://www.mercadolivre.com.br/mais-vendidos/MLB1055',
  'smartphones':  'https://www.mercadolivre.com.br/mais-vendidos/MLB1055',
  'tablets':      'https://www.mercadolivre.com.br/mais-vendidos/MLB1051',
  'tablet':       'https://www.mercadolivre.com.br/mais-vendidos/MLB1051',
  'notebooks':    'https://www.mercadolivre.com.br/mais-vendidos/MLB1648',
  'notebook':     'https://www.mercadolivre.com.br/mais-vendidos/MLB1648',
  'smartwatch':   'https://www.mercadolivre.com.br/mais-vendidos/MLB1271',
  'fone':         'https://www.mercadolivre.com.br/mais-vendidos/MLB1316',
  'fones':        'https://www.mercadolivre.com.br/mais-vendidos/MLB1316',
  // Marcas → URL de mais vendidos com filtro de marca
  'xiaomi':   'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=9344',
  'samsung':  'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=206',
  'apple':    'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=9127',
  'iphone':   'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=9127',
  'motorola': 'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=595',
  'realme':   'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=491837',
  'infinix':  'https://www.mercadolivre.com.br/mais-vendidos/MLB1055?BRAND_ID=1031956',
};

exports.handler = async (event) => {
  const cors = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
    'Content-Type': 'application/json',
  };
  if (event.httpMethod === 'OPTIONS') return { statusCode: 200, headers: cors, body: '' };

  const q    = ((event.queryStringParameters || {}).q || 'celulares').toLowerCase().trim();
  const type = (event.queryStringParameters || {}).type || 'category';

  // Normaliza query
  const qNorm = q.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().trim();

  // Encontra URL correta
  let url      = MAIS_VENDIDOS[qNorm] || MAIS_VENDIDOS[q];
  let catLabel = q.charAt(0).toUpperCase() + q.slice(1);

  if (!url) {
    // Fallback para celulares
    url      = MAIS_VENDIDOS['celulares'];
    catLabel = 'Celulares';
  }

  try {
    const r = await fetchML(url);

    if (r.status !== 200) {
      return {
        statusCode: 200,
        headers: cors,
        body: JSON.stringify({ items: [], category: catLabel, error: `HTTP ${r.status} ao acessar ML`, html_len: r.html?.length })
      };
    }

    const items = extractProducts(r.html);

    // Para busca por marca, filtra adicionalmente pelo nome
    const filtered = (type === 'brand' && !MAIS_VENDIDOS[qNorm]?.includes('BRAND_ID'))
      ? items.filter(i => i.title.toLowerCase().includes(qNorm))
      : items;

    return {
      statusCode: 200,
      headers: cors,
      body: JSON.stringify({
        items: filtered.slice(0, 30),
        category: catLabel,
        type,
        html_len: r.html.length,
        total: filtered.length,
        // Debug: primeiros 3000 chars do HTML para ver estrutura
        html_sample: r.html.slice(0, 3000),
      })
    };

  } catch (e) {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: e.message, items: [] }) };
  }
};
