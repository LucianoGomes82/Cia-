// Proxy especializado para baixar binários do ML (PDFs, ZPL, etc.)
// Retorna o conteúdo em base64 (Netlify Functions exige isBase64Encoded: true para binários).
const https = require("https");

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, OPTIONS",
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers: { ...cors, "Content-Type": "application/json" }, body: "" };
  }

  const mlPath = event.queryStringParameters?.path || "";
  const rawToken = event.headers["authorization"] || event.headers["Authorization"] || "";

  if (!mlPath) {
    return {
      statusCode: 400,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ error: "path query param required" }),
    };
  }

  const mlHeaders = {
    "Accept": "application/pdf, application/octet-stream, */*",
    "User-Agent": "Mozilla/5.0",
  };
  if (rawToken) mlHeaders["Authorization"] = rawToken;

  const options = {
    hostname: "api.mercadolibre.com",
    port: 443,
    path: mlPath,
    method: "GET",
    headers: mlHeaders,
  };

  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      const chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("end", () => {
        const buffer = Buffer.concat(chunks);
        const contentType = res.headers["content-type"] || "application/pdf";

        // Se for erro (não 2xx), tenta retornar como JSON em texto
        if (res.statusCode >= 400) {
          resolve({
            statusCode: res.statusCode,
            headers: { ...cors, "Content-Type": "application/json" },
            body: JSON.stringify({
              error: `ML returned ${res.statusCode}`,
              detail: buffer.toString("utf-8").slice(0, 1000),
            }),
          });
          return;
        }

        resolve({
          statusCode: res.statusCode,
          headers: {
            ...cors,
            "Content-Type": contentType,
          },
          body: buffer.toString("base64"),
          isBase64Encoded: true,
        });
      });
    });

    req.on("error", (err) => {
      resolve({
        statusCode: 500,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({ error: err.message, detail: "proxy_error" }),
      });
    });

    req.end();
  });
};
