const https = require("https");

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Allow-Methods": "GET, POST, PATCH, DELETE, OPTIONS",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: cors, body: "" };

  const mlPath = event.queryStringParameters?.path || "/users/me";
  const rawToken = event.headers["authorization"] || event.headers["Authorization"] || "";
  const method  = event.httpMethod;
  const body    = event.body || "";

  // Encaminha apenas headers essenciais — sem host, x-forwarded-*, etc.
  const mlHeaders = {
    "Accept": "application/json",
    "Content-Type": "application/json",
    "User-Agent": "Mozilla/5.0",
  };
  if (rawToken) mlHeaders["Authorization"] = rawToken;
  if (body)     mlHeaders["Content-Length"] = String(Buffer.byteLength(body));

  const options = {
    hostname: "api.mercadolibre.com",
    port: 443,
    path: mlPath,
    method,
    headers: mlHeaders,
  };

  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (chunk) => (data += chunk));
      res.on("end", () => {
        resolve({
          statusCode: res.statusCode,
          headers: cors,
          body: data,
        });
      });
    });

    req.on("error", (err) => {
      resolve({
        statusCode: 500,
        headers: cors,
        body: JSON.stringify({ error: err.message, detail: "proxy_error" }),
      });
    });

    if (body) req.write(body);
    req.end();
  });
};
