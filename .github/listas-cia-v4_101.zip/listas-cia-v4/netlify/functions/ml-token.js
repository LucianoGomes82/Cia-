const https = require("https");

exports.handler = async (event) => {
  const cors = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Content-Type": "application/json",
  };

  if (event.httpMethod === "OPTIONS") return { statusCode: 200, headers: cors, body: "" };
  if (event.httpMethod !== "POST")    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: "Method not allowed" }) };

  let params;
  try { params = JSON.parse(event.body || "{}"); } catch { params = {}; }

  // Monta o body como form-urlencoded
  const formBody = Object.entries(params)
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
    .join("&");

  const options = {
    hostname: "api.mercadolibre.com",
    port: 443,
    path: "/oauth/token",
    method: "POST",
    headers: {
      "Accept":         "application/json",
      "Content-Type":   "application/x-www-form-urlencoded",
      "Content-Length": String(Buffer.byteLength(formBody)),
    },
  };

  return new Promise((resolve) => {
    const req = https.request(options, (res) => {
      let data = "";
      res.on("data", (c) => (data += c));
      res.on("end", () => resolve({ statusCode: res.statusCode, headers: cors, body: data }));
    });
    req.on("error", (e) => resolve({ statusCode: 500, headers: cors, body: JSON.stringify({ error: e.message }) }));
    req.write(formBody);
    req.end();
  });
};
